import React from "react";
import styles from "./ListOfExtension.module.scss";

function ListOfExtension({ extensionList, filteredData }) {
  const renderExtensionList = (channelExtension, destChannelExtension) => {
    return (
      <ul>
        {Object.entries(extensionList).map(([extension, status]) => (
          <li
            key={extension}
            style={{
              borderColor: status === "Unavailable" ? "red" : "gray",
              backgroundColor:
                extension === channelExtension ||
                extension === destChannelExtension
                  ? "#7fff7f"
                  : "transparent",
            }}
          >
            <h3>Extension: {extension}</h3>
            <p>Status: {status}</p>

            {(extension === channelExtension ||
              extension === destChannelExtension) && (
              <span className={styles.testIcon}>★</span>
            )}
          </li>
        ))}
      </ul>
    );
  };

  let channelExtension = null;
  let destChannelExtension = null;

  if (filteredData) {
    const { Channel, DestChannel } = filteredData;

    channelExtension = Channel.split("/")[1].split("-")[0];

    destChannelExtension = DestChannel.split("/")[1].split("-")[0];
  }

  return (
    <div className={styles.card}>
      <h4>Extension List:</h4>
      {renderExtensionList(channelExtension, destChannelExtension)}
    </div>
  );
}

export default ListOfExtension;
